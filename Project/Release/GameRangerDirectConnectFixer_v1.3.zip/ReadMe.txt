GameRanger Direct Connect Fixer for COMMAND AND CONQUER GENERALS: ZERO HOUR

Author:
xezon

-------------------------------------------------------------------------------
--- Install Method #1 ---------------------------------------------------------

1. Run DirectConnectFixer.exe and follow the instructions


-------------------------------------------------------------------------------
--- Install Method #2 ---------------------------------------------------------

1. Close game

2. Run registry\win64_UserDataLeafName.reg
     or registry\win32_UserDataLeafName.reg
     depending on the type of the operating system

3. Open %USERPROFILE%\Documents\
     or %USERPROFILE%\My Documents\
     in Windows Explorer

4. Rename Zero Hour user data folder to
     'Command and Conquer Generals Zero Hour Data'


-------------------------------------------------------------------------------
--- Changelog -----------------------------------------------------------------

v1.0
- Initial release

v1.1
- Minor improvements

v1.2
- Added fallback functionality to revert partial changes
    if other changes fail to complete
- Added more pedantic debug text output
- Refactored code

v1.3
- Fixed an issue where game user data folder was not recognized by the program